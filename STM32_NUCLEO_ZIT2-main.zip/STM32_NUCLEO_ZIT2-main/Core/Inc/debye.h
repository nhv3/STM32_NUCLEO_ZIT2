//This header file is just to include some of the commonly passed variables from one file to another. MAKE SURE THESE VAIRBALES ARE NOT STATIC IN THEIR DEFINITION

extern uint8_t rxdata;
extern uint32_t rxlen;

